#include "dlist.h"

/*to insert a new node at the end of the list*/
int insert_at_last(dlist **head, dlist **tail, data_i n_data)
{
	/*create a new node*/
	dlist *new = malloc(sizeof(dlist));
	
	if(new == NULL)
		return FAILURE;
		
	/*update new node data*/	
	new -> data = n_data;
	new -> prev = NULL;
	new -> next = NULL;
	
	/*if no element is present update head*/
	if(*head == NULL)
	{
		*head = new;
	}
	/*establish link between new node and tail*/
	else
	{
		(*tail) -> next  = new;
		new -> prev = *tail;
	}
	*tail = new;
	return SUCCESS;
}
	
	
	
	
	
