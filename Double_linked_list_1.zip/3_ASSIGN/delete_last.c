#include "dlist.h"

/*to delete the last node in the list*/
int delete_last(dlist **head, dlist **tail)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	dlist *temp = *tail;
	
	/*if one node is present in the list*/
	if(*head == *tail)
	{
		free(temp);
		*head = *tail = NULL;
	}
	else
	{
		(*tail) -> prev -> next = NULL;
		*tail = temp -> prev;
		free(temp);
	}
	return SUCCESS; 	
}



