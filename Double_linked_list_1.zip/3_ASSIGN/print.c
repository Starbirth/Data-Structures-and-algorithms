#include "dlist.h"

 /*to print the node data in the list*/
int print_list(dlist *head)
{
	if(head == NULL)
	{
		return FAILURE;
	}
	printf("\nhead -> ");
	while(head != NULL)
	{
		printf("[%d] <-> ", head -> data);		//print head -> data, and traverse through the list
		head = head -> next;
	}
	printf("\b\b tail\n");
	return SUCCESS;
}
