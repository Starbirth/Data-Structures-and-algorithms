#include "dlist.h"

/*to insert a new node at the start of the list*/
int insert_at_first(dlist **head, dlist **tail, data_i n_data)
{
	/*create a new node*/
	dlist *new = malloc(sizeof(dlist));
	
	if(new == NULL)
		return FAILURE;
		
	/*update new node data*/	
	new -> data = n_data;
	new -> prev = NULL;
	new -> next = NULL;
	
	/*if list is empty update tail*/
	if(*head == NULL)
	{
		*tail = new;
	}
	/*establish link between new node and head*/
	else
	{
		(*head) -> prev = new;
	 	new -> next = *head;	
	}
	*head = new;
	return SUCCESS;
}	
