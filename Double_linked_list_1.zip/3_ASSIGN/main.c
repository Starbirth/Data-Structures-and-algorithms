/**************************************************************************
DOCUMENTATION:
NAME 			: V. KARTHIKEYAN
DATE				: 21.08.2021
DESCRIPTION		: Implement functions given below.
				  1. dll_insert_first(head, tail, data)
				  2. dll_insert_last(head, tail, data)
				  3. dll_delete_first(head, tail)
				  4. dll_delete_last(head, tail)
				  5. dll_delete_list(head, tail)
				  
INPUT AND OUTPUT	:

./a.out

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :
1
Enter the data to be inserted :5
The data 5 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :1
Enter the data to be inserted :8
The data 8 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [8] <-> [5] <- tail
DO YOU WANT TO CONTINUE (y/Y): n
-----------------------------------------------------------------
./a.out

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :2
Enter the data to be inserted :4
The data 4 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :2
Enter the data to be inserted :8
The data 8 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [4] <-> [8] <- tail
DO YOU WANT TO CONTINUE (y/Y): n
-----------------------------------------------------------------
./a.out

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :1
Enter the data to be inserted :5
The data 5 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :1
Enter the data to be inserted :6
The data 6 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [6] <-> [5] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :3
The first node is deleted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [5] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :1
Enter the data to be inserted :8
The data 8 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [8] <-> [5] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :4
The last node is deleted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6

head -> [8] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :1
Enter the data to be inserted :5
The data 5 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :5
The whole list is deleted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at first
2. Insert at last
3. Delete first node
4. Delete last node
5. Delete list
6. Print list
Enter your choice :6
No link is present
DO YOU WANT TO CONTINUE (y/Y): n


*************************************************************************/
#include "dlist.h"

int main()
{
	/*declare variables*/
	data_i g_data, n_data, ch, ret;
	char choice;

	/*creating a list with head and tail*/
	dlist *head = NULL;
	dlist *tail = NULL;
	
	do
	{
		printf("\n1. Insert at first\n2. Insert at last\n3. Delete first node\n4. Delete last node\n5. Delete list\n6. Print list\nEnter your choice :");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1:
			/*to insert the node at the start of the list*/
				printf("Enter the data to be inserted :");
				scanf("%d", &n_data);
				if( (ret = insert_at_first(&head, &tail, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else
				{
					printf("Failed to create a new node\n");
				}
				break;
			case 2:
			/*to insert the node at the end of the list*/
				printf("Enter the data to be inserted :");
				scanf("%d", &n_data);
				if( (ret = insert_at_last(&head, &tail, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else
				{
					printf("Failed to create a new node\n");
				}
				break;
			case 3:
			/*to delete the first node of the list*/
				if( (ret = delete_first(&head, &tail)) == SUCCESS )
				{
					printf("The first node is deleted successfully\n");
				}
				else 
				{
					printf("No link is present\n");
				}
				break;
			case 4:
			/*to delete the last node of the list*/
				if( (ret = delete_last(&head, &tail)) == SUCCESS )
				{
					printf("The last node is deleted successfully\n");
				}
				else 
				{
					printf("No link is present\n");
				}
				break;
			case 5:
			/*delete the whole list and free the memory*/
				if( (ret = delete_list(&head, &tail)) == SUCCESS )
				{
					printf("The whole list is deleted successfully\n");
				}
				else 
				{
					printf("No link is present\n");
				}
				break;
			case 6:
			/*to print the list*/
				if( print_list(head) != SUCCESS) 
					printf("No link is present\n");
				break;
			default:
				printf("Error : Invalid choice of operation\n");
				break;
			}	
	printf("DO YOU WANT TO CONTINUE (y/Y): ");
	scanf(" %c",&choice);
	} while(choice == 'Y' || choice == 'y');
	
	return 0;
}




