#ifndef DLIST_H
#define DLIST_H

#include<stdio.h>
#include<stdlib.h>

/*define MACROs*/
#define SUCCESS 0
#define FAILURE -1
#define DATA_NOT_FOUND -2
#define EMPTY_LIST -3

typedef int data_i;

/*creating double linked list structure*/
typedef struct node
{
	struct node *prev;
	data_i data;
	struct node *next;
} dlist;

/*to insert a new node at the start of the list*/
int insert_at_last(dlist **head, dlist **tail, data_i n_data);

/*to insert a new node at the end of the list*/
int insert_at_first(dlist **head, dlist **tail, data_i n_data);

/*print the list*/
int print_list(dlist *head);

/*to delete the first node of the list*/
int delete_first(dlist **head, dlist **tail);

/*to delete the last node of the list*/
int delete_last(dlist **head, dlist **tail);

/*to delete the whole list*/
int delete_list(dlist **head, dlist **tail);
	
#endif



