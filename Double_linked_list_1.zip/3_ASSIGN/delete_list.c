#include "dlist.h"

/*to delete the whole list*/
int delete_list(dlist **head, dlist **tail)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	dlist *temp = *head;
	
	/*updating head and next node, free memory till NULL*/
	while(temp -> next != NULL)	//for n-1 iterations
	{
		*head = temp -> next;
		(*head) -> prev = temp -> prev;
		free(temp);
		temp = *head;
	}
	/*for last node*/
	*head = NULL;
	free(temp);
	*tail = NULL;
	return SUCCESS; 	
}


