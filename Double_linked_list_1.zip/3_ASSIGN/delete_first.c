#include "dlist.h"

/*to delete the first node in the list*/
int delete_first(dlist **head, dlist **tail)
{
	if(*head == NULL)
		return EMPTY_LIST;
	dlist *temp = *head;
	
	/*if list contains only one node*/
	if(*head == *tail)
	{
		free(temp);
		*head = *tail = NULL;
	}
	/*else update head and second node*/
	else
	{
		(*head) -> next -> prev = NULL;
		*head = temp -> next;
		free(temp);
	}
	return SUCCESS; 	
}


