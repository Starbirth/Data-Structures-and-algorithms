#include "slist.h"
 
 /*to print the list from head to NULL*/
int print_list(slist *head)
{
	if(head == NULL)
	{
		return FAILURE;
	}
	printf("\nhead-> ");
	while(head != NULL)
	{
		printf("%d -> ", head -> data);
		head = head -> link;
	}
	printf("null\n");
	return SUCCESS;
}
