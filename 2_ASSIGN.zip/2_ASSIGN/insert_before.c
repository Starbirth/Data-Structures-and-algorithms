#include "slist.h"

/*to insert a node before the given data*/
int insert_before(slist **head, data_i g_data, data_i n_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
	
	slist *temp = *head, *prev = *head;
	
	while(temp != NULL)
	{
		if(temp -> data != g_data)
		{
			prev = temp;
			temp = temp -> link;
		}
		else
		{
			slist *new = malloc (sizeof(slist));
			if( new == NULL)
				return FAILURE;
			
			new -> data = n_data;
			
			if(temp == *head)
				*head = new;
			else
				prev -> link = new;
			
			new -> link = temp;
			
		return SUCCESS;
		}
	}
	return DATA_NOT_FOUND;

}
