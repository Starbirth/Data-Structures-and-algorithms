#include "slist.h"

int insert_after(slist **head, data_i g_data, data_i n_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	slist *temp = *head;
	
	while (temp != NULL)
	{
		if(temp -> data != g_data)
		{
			temp = temp -> link;
		}
		else
		{
			slist *new = malloc(sizeof(slist));
			if(new == NULL)
				return FAILURE;
			
			new -> data = n_data;
			new -> link = temp -> link;
			temp -> link = new;
			return SUCCESS;	
		} 
	}
	return DATA_NOT_FOUND;
}



