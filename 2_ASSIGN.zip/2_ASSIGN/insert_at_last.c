#include "slist.h"

/*to insert a node at the last position in the list*/
int insert_at_last(slist **head, data_i n_data)
{
	slist *new = malloc(sizeof(slist));
	
	if(new == NULL)
		return FAILURE;
	new -> data = n_data;
	new -> link = NULL;
	
	if(*head == NULL)
	{
		*head = new;
	}
	else
	{
		slist *temp = *head;
		while ( temp -> link )
		{
			temp = temp -> link;
		}
		temp -> link = new;
	}
	return SUCCESS;
}
	
	
	
	
	
