#ifndef SLIST_H
#define SLIST_H

#define SUCCESS 0
#define FAILURE -1
#define DATA_NOT_FOUND -2
#define EMPTY_LIST -3
#define POSITION_NOT_FOUND -4

#include<stdio.h>
#include<stdlib.h>

typedef int data_i;
typedef struct node
{
	data_i data;
	struct node *link;
} slist;

/*to insert the node at the last of the list*/
int insert_at_last(slist **head, data_i n_data);

/*to insert after a given node of data*/
int insert_after(slist **head, data_i g_data, data_i n_data);

/*to insert a new node before the given node of data*/
int insert_before(slist **head, data_i g_data, data_i n_data);

/*element node*/
int delete_element(slist **head, data_i data);

/*insert in the nth position*/
int insert_nth(slist **head, data_i n, data_i n_data);

/*print the list*/
int print_list(slist *head);

#endif		
