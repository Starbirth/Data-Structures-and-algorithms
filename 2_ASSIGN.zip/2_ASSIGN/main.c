/**************************************************************
DOCUMENTATION:
NAME				: V. KARTHIKEYAN
DATE 			: 22.08.2021
DESCRIPTION		: Implement the functions given below.
				  1. insert_after(head, gdata, ndata)
				  2. insert_before(head, gdata, ndata)
				  3. delete_element(head, gdata)
				  4. insert_Nth(head, ndata, n)

INPUT AND OUTPUT	: ./a.out

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :1
Enter the data to be inserted :5
The data 5 is inserted successfully

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :2
Enter the node data to be found : 5
Enter the node data to be inserted after 5 : 8
The data 8 is inserted successfully

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :6

head-> 5 -> 8 -> null

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :3
Enter the node data to be found : 8
Enter the node data to be inserted after 8 : 2
The data 2 is inserted successfully

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :6

head-> 5 -> 2 -> 8 -> null

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :4
Enter the node data to be deleted : 2
The data 2 is deleted successfully

DO YOU WANT TO CONTINUE(y/Y) :
y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :6

head-> 5 -> 8 -> null

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :5
Enter the nth node to be inserted : 2
Enter the node data to be inserted in 2th position : 9
The data 9 is inserted successfully

DO YOU WANT TO CONTINUE(y/Y) :y

1. Insert node
2. Insert after node
3. Insert before node
4. Delete node
5. Insert at nth node
6. Print list
Enter your choice :6

head-> 5 -> 9 -> 8 -> null

DO YOU WANT TO CONTINUE(y/Y) :n

**************************************************************/
#include "slist.h"

int main()
{
	slist *head = NULL;
	data_i n_data, g_data, ret, ch, n;
	char  choice;
	do
	{
		printf("\n1. Insert node\n2. Insert after node\n3. Insert before node\n4. Delete node\n5. Insert at nth node\n6. Print list\nEnter your choice :");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1:
				printf("Enter the data to be inserted :");
				scanf("%d", &n_data);
				if( (ret = insert_at_last(&head, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else
				{
					printf("No link is present\n");
				}
				break;
			case 2:
				printf("Enter the node data to be found : ");
				scanf("%d", &g_data);
				printf("Enter the node data to be inserted after %d : ",g_data);
				scanf("%d", &n_data);
				if( (ret = insert_after (&head, g_data, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else if( ret == DATA_NOT_FOUND )
				{
					printf("The node data %d is not present in the link\n",g_data);
				}
				else if( ret == FAILURE )
				{
					printf("Unable to create new node");
				}
				else
				{
					printf("No link is present\n");
				}
				break;
			case 3:
				printf("Enter the node data to be found : ");
				scanf("%d", &g_data);
				printf("Enter the node data to be inserted after %d : ",g_data);
				scanf("%d", &n_data);
				if( (ret = insert_before (&head, g_data, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else if( ret == DATA_NOT_FOUND )
				{
					printf("The node data %d is not present in the link\n",g_data);
				}
				else if( ret == FAILURE )
				{
					printf("Unable to create new node");
				}
				else
				{
					printf("No link is present \n");
				}
				break;
			case 4:
				printf("Enter the node data to be deleted : ");
				scanf("%d", &n_data);
				if( (ret = delete_element (&head, n_data)) == SUCCESS )
				{
					printf("The data %d is deleted successfully\n",n_data);
				}
				else if( ret == DATA_NOT_FOUND )
				{
					printf("The node data %d is not present in the link\n",n_data);
				}
				else
				{
					printf("No link is present \n");
				}
				break;
			
			case 5:
				printf("Enter the nth node to be inserted : ");
				scanf("%d", &n);
				printf("Enter the node data to be inserted in %dth position : ",n);
				scanf("%d", &n_data);
				if( (ret = insert_nth (&head, n, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else if( ret == POSITION_NOT_FOUND )
				{
					printf("The position %d is not present in the link\n",n);
				}
				else if( ret == FAILURE )
				{
					printf("Unable to create new node");
				}
				break;
				
			case 6:
				if(print_list(head) != SUCCESS)
				{
					printf("No link is present\n");
				}
				break;
		}
	
	printf("\nDO YOU WANT TO CONTINUE(y/Y) :");
	scanf(" %c",&choice);			
	} while(choice == 'y' || choice =='Y');			
				
	
	return 0;
}
