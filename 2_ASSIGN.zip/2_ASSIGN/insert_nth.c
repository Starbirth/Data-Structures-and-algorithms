#include "slist.h"

int insert_nth(slist **head, data_i n, data_i n_data)
{
	data_i pos = 1;
	/*if n is given 1 and list is empty*/
	if(*head == NULL)
	{
		if(n == 1)
		{ 
			slist *new = malloc (sizeof(slist));
			if(new == NULL)	
				return FAILURE;
			
			new -> data = n_data;
			new -> link = NULL;
			*head = new;
			return SUCCESS;
		}
		else if(n > 1)
		{
			return POSITION_NOT_FOUND;
		}	
	}
	
	slist *temp = *head, *prev = *head;
	
	/*to search for the position till reach the end of the list*/
	while(temp != NULL)
	{
		if(pos == n )
		{
			slist *new = malloc (sizeof(slist));
			if(new == NULL)
				return FAILURE;
			
			if(temp == *head)
				*head = new;
			else
				prev -> link = new;
			
			new -> data = n_data;
			new-> link = temp;
			return SUCCESS;
		}	
		pos++;
		prev = temp;
		temp = temp -> link;
	}	
	
	/*if n is (end+1)th position in the list add it as last node*/
	if(pos == n)
	{
		slist *new = malloc (sizeof(slist));
			if(new == NULL)
				return FAILURE;
		
		prev -> link = new;
		new -> data = n_data;
		new -> link = NULL;
		return SUCCESS;
	}
	return POSITION_NOT_FOUND;		
}
