#include "slist.h"

/*to delete the node in a list*/
int delete_element(slist **head, data_i n_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
	
	slist *temp = *head, *prev = *head;
	
	while(temp != NULL)
	{
		if(temp -> data != n_data)
		{
			prev = temp;
			temp = temp -> link;
		}
		else
		{
			if ( temp == *head )
			{
				*head = NULL;
			}
			else
			{
				prev -> link = temp -> link;	
			} 
			free(temp);
			return SUCCESS;
		}
	}
	
	return DATA_NOT_FOUND;
}
