#include "slist.h"

int delete_list(slist_t **head)
{
	if( *head == NULL )
		return EMPTY_LIST;
	
	slist_t *temp = *head;
	slist_t *delete_node = temp;
	while(temp != NULL)
	{
		temp = temp -> link;
		free(delete_node);
		delete_node = temp;
	}
	*head = NULL;
	return SUCCESS;
}
