#include "slist.h"

int print_list(slist_t *head)
{
	if(head == NULL)
	{
		printf("NO LINK IS PRESENT\n");
		return FAILURE;
	}
	printf("\nhead-> ");
	while(head != NULL)
	{
		printf("%d -> ", head -> data);
		head = head -> link;
	}
	printf("null\n");
	return SUCCESS;
}
