/*******************************************************
DOCUMENTATION

NAME			: V.KARTHIKEYAN
DATE			: 19.08.2021
DOCUMENTATION	: Implement the functions given below :-
			  1. insert_at_first(head, data)
			  2. insert_at_last(head, data)
			  3. delete_first(head)
			  4. delete_last(head)
			  5. delete_list(head)
			  6. find_node(head, data)

INPUT & OUTPUT :
 ./a.out

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 9
INFO : The given data 9 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :7

head-> 5 -> 9 -> null

DO YOU WANT TO CONTINUE (Y/y) :n
----------------------------------------------------------------------
./a.out

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :2
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :2
Enter the new data to be inserted : 7
INFO : The given data 7 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :7

head-> 7 -> 5 -> null

DO YOU WANT TO CONTINUE (Y/y) : n
--------------------------------------------------------------------
1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 8
INFO : The given data 8 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :3
INFO : the first node is deleted successfully

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :7

head-> 8 -> null

DO YOU WANT TO CONTINUE (Y/y) : n
--------------------------------------------------------------
./a.out

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 9
INFO : The given data 9 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :4
INFO : the last node is deleted successfully

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :7

head-> 5 -> null

DO YOU WANT TO CONTINUE (Y/y) : n
--------------------------------------------------------------
./a.out

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :5
Enter the node data need to be searched :5
The Node is found in the list

DO YOU WANT TO CONTINUE (Y/y) : n
--------------------------------------------------------------
./a.out

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :1
Enter the new data to be inserted : 5
INFO : The given data 5 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :2
Enter the new data to be inserted : 6
INFO : The given data 6 inserted successfully in list

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :6
The list is deleted

DO YOU WANT TO CONTINUE (Y/y) : y

1. Insert at last
2. Insert at first
3. Delete first node
4. Delete last node
5. Find node
6. Delete list
7. Print list
Enter your choice :7
NO LINK IS PRESENT

DO YOU WANT TO CONTINUE (Y/y) : n

********************************************************************/

#include "slist.h"

int main()
{
	slist_t *head = NULL;
	data_t n_data, choice, g_data, ret;
	char ch;
	
	do
	{
		printf("\n1. Insert at last\n2. Insert at first\n3. Delete first node\n4. Delete last node\n5. Find node\n6. Delete list\n7. Print list\nEnter your choice :");
		scanf(" %d", &choice);
		switch (choice)
		{
			case 1:
				printf("Enter the new data to be inserted : ");
				scanf("%d", &n_data);
				if( insert_at_last(&head, n_data) == SUCCESS)
				{
					printf("INFO : The given data %d inserted successfully in list\n",n_data);
				}
				else
				{
					printf("ERROR : Insertion is failure\n");
				}
				break;
				
			case 2:
				printf("Enter the new data to be inserted : ");
				scanf("%d", &n_data);
				if( insert_at_first(&head, n_data) == SUCCESS)
				{
					printf("INFO : The given data %d inserted successfully in list\n",n_data);
				}
				else
				{
					printf("ERROR : Insertion is failure\n");
				}
				break;
				
			case 3:
				if( delete_first(&head) == SUCCESS)
				{
					printf("INFO : the first node is deleted successfully\n");
				}
				else
				{
					printf("INFO : LIST IS EMPTY\n");
				}
				break;
				
			case 4:
				if( delete_last(&head) == SUCCESS)
				{
					printf("INFO : the last node is deleted successfully\n");
				}
				else
				{
					printf("INFO : LIST IS EMPTY\n");
				}
				break;
				
			case 5:
				printf("Enter the node data need to be searched :");
				scanf("%d",&g_data);
				if( (ret = find_node(&head, g_data)) == SUCCESS)
				{
					printf("The Node is found in the list\n");
				}
				else if( ret == DATA_NOT_FOUND)
				{
					printf("INFO : The node is not present in the list\n");
				}
				else if( ret == EMPTY_LIST )
				{
					printf("INFO : LIST IS EMPTY\n");
				}
				break;
				
			case 6:
				if( (ret = delete_list(&head)) == SUCCESS)
				{
					printf("The list is deleted\n");
				}
				else if(ret == EMPTY_LIST)
				{
					printf("INFO : LIST IS EMPTY\n");
				}
				break;
				
			case 7:
				print_list(head);
				break;	
							
			default:
				printf("\nNOTICE : INVALID CHOICE OF OPERATION\n");
				break;
		} 
		__fpurge(stdin);
		printf("\nDO YOU WANT TO CONTINUE (Y/y) : ");
		scanf(" %c", &ch);
	}while (ch == 'y' || ch == 'Y');
	return 0;
} 	
					
					
					
					
					
					
					
					
					
					
					
					
					
