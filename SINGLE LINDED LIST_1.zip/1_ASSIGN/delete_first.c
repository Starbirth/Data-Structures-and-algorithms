#include "slist.h"

int delete_first(slist_t **head)
{
	if(*head == NULL)
		return EMPTY_LIST;
	slist_t *temp = *head;
	*head = temp -> link;
	free(temp);
	return SUCCESS;
}

