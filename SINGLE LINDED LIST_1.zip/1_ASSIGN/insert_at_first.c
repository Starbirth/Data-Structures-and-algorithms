#include "slist.h"
int insert_at_first(slist_t **head, data_t n_data)
{
	slist_t *new = malloc(sizeof(slist_t));
	
	if(new == NULL)
		return FAILURE;
	new -> data = n_data;
	new -> link = NULL;
	
	if(*head != NULL)
	{
		new -> link = *head;
	}	
	*head = new;
	
	return SUCCESS;
}
