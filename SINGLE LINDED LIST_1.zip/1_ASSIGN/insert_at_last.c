#include "slist.h"

int insert_at_last(slist_t **head, data_t n_data)
{
	slist_t *new = malloc(sizeof(slist_t));
	
	if(new == NULL)
		return FAILURE;
	new -> data = n_data;
	new -> link = NULL;
	
	if(*head == NULL)
	{
		*head = new;
	}
	else
	{
		slist_t *temp = *head;
		while ( temp -> link )
		{
			temp = temp -> link;
		}
		temp -> link = new;
	}
	return SUCCESS;
}
	
	
	
	
	
