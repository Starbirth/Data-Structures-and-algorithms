#include "slist.h"

int delete_last(slist_t **head)
{
	if(*head == NULL)
		return EMPTY_LIST;
	
	slist_t *prev = *head, *temp = *head;
	
	if(temp -> link == NULL)
	{	
		*head = NULL;
	}
	else
	{
		while(temp -> link != NULL)
		{
			prev= temp;
			temp = temp -> link;
		}
		prev -> link = NULL;
	}
	free(temp);
	return SUCCESS;
}
