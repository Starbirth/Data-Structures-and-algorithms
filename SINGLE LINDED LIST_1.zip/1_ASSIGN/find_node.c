#include "slist.h"

int find_node(slist_t **head, int g_data)
{
	if( *head == NULL )
		return EMPTY_LIST;
	
	slist_t *temp = *head;
	while( temp != NULL)
	{
		if(temp -> data == g_data)
			return SUCCESS;
		temp = temp -> link;
	}
	return DATA_NOT_FOUND;
}
