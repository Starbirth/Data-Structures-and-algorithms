#ifndef SLIST_H
#define SLIST_H

#define SUCCESS 0
#define FAILURE -1
#define DATA_NOT_FOUND -2
#define EMPTY_LIST -3

/*headers inclusion*/
#include <stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>


typedef int data_t;

typedef struct node
{
	data_t data;
	struct node *link;
}slist_t;

/*to insert node at the end of link*/
int insert_at_last(slist_t **head, data_t n_data);

/*insert node at the start of the link*/
int insert_at_first(slist_t **head, data_t n_data);

/*delete the first node*/
int delete_first(slist_t **head);

/*delete the last node*/
int delete_last(slist_t **head);

/*to find if the node is present or not*/
int find_node(slist_t **head, int data);

/*to deallocate the memory and delete the whole list*/
int delete_list(slist_t **head);

/*to print the list*/
int print_list(slist_t *head);

#endif
