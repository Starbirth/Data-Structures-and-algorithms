#include "dlist.h"
 
/*to print the list*/
int print_list(dlist *head)
{
	if(head == NULL)
	{
		return FAILURE;
	}
	printf("\nhead -> ");
	while(head != NULL)
	{
		printf("[%d] <-> ", head -> data);
		head = head -> next;
	}
	printf("\b\b tail\n");
	return SUCCESS;
}
