#include "dlist.h"

/*insert a new node before the node that contains the given data*/
int insert_before(dlist **head, dlist **tail, data_i g_data, data_i n_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	dlist *temp = *head;
	
	while (temp != NULL)
	{
		if(temp -> data != g_data)
		{
			temp = temp -> next;
		}
		else
		{
			dlist *new = malloc(sizeof(dlist));
			if(new == NULL)
				return FAILURE;
			
			new -> data = n_data;	
			
			/*if given data is at first node*/
			if(temp  == *head)
			{
				*head = new;
			}
			else
			{
				temp -> prev -> next = new;
			}
			/*establish link between new node and temp node*/
			new -> prev = temp -> prev;
			new -> next = temp;
			temp -> prev = new;
			return SUCCESS;	
		} 
	}
	return DATA_NOT_FOUND;
}



