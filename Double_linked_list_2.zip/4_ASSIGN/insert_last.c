#include "dlist.h"

/*insert a new node at the last of the list*/
int insert_at_last(dlist **head, dlist **tail, data_i n_data)
{
	dlist *new = malloc(sizeof(dlist));
	
	if(new == NULL)
		return FAILURE;
	new -> data = n_data;
	new -> prev = NULL;
	new -> next = NULL;
	
	if(*head == NULL)
	{
		*head = new;
	}
	else
	{
		(*tail) -> next  = new;
		new -> prev = *tail;
	}
	*tail = new;
	return SUCCESS;
}
	
	
	
	
	
