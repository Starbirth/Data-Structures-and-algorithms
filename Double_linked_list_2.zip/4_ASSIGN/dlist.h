#ifndef DLIST_H
#define DLIST_H

/*include headers*/
#include<stdio.h>
#include<stdlib.h>

/*define MACROs*/
#define SUCCESS 0
#define FAILURE -1
#define DATA_NOT_FOUND -2
#define EMPTY_LIST -3

typedef int data_i;

/*creating structure node*/
typedef struct node
{
	struct node *prev;
	data_i data;
	struct node *next;
} dlist;

/*insert a new node at the last of the list*/
int insert_at_last(dlist **head, dlist **tail, data_i n_data);

/*insert a new node after the node that contains given data*/
int insert_after(dlist **head, dlist **tail, data_i g_data, data_i n_data);

/*insert a new node before the node that contains the given data*/
int insert_before(dlist **head, dlist **tail, data_i g_data, data_i n_data);

/*delete the node with the given data*/
int delete_element(dlist **head, dlist **tail, data_i g_data);

/*print the list*/
int print_list(dlist *head);

#endif



