#include "dlist.h"

/*to delete the node that contains the given data*/
int delete_element(dlist **head, dlist **tail, data_i g_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	dlist *temp = *head;
	
	while (temp != NULL)
	{
		if(temp -> data != g_data)
		{
			temp = temp -> next;
		}
		else
		{	/*if list contains only one node*/
			if(*head == *tail)
			{
				*head = temp -> next;
				*tail = temp -> prev;
			}
			/*if the given data is in the first node*/
			else if(temp  == *head)
			{
				*head = temp -> next;
				temp -> next -> prev = NULL;
			}
			/*if the given data is in the last node*/
			else if(temp == *tail)
			{
				*tail = temp -> prev;
				temp -> prev -> next = NULL; 
			}
			/*between the list*/
			else 
			{
				temp -> prev -> next = temp -> next;
				temp -> next -> prev = temp -> prev;
			}
			
			free(temp);
			return SUCCESS;	
		} 
	}
	return DATA_NOT_FOUND;
}



