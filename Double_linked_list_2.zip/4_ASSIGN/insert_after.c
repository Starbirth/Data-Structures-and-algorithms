#include "dlist.h"

/*insert a new node after the node that contains given data*/
int insert_after(dlist **head, dlist **tail, data_i g_data, data_i n_data)
{
	if(*head == NULL)
		return EMPTY_LIST;
		
	dlist *temp = *head;
	
	while (temp != NULL)
	{
		if(temp -> data != g_data)
		{
			temp = temp -> next;
		}
		else
		{
			dlist *new = malloc(sizeof(dlist));
			if(new == NULL)
				return FAILURE;
			
			new -> data = n_data;
			new -> next = temp -> next;
			new -> prev = temp;
			
			
			if(temp != *tail)
				temp -> next -> prev = new;
			/*given data is at the last node*/
			else
				*tail = new;
				
			temp -> next = new;
			return SUCCESS;	
		} 
	}
	return DATA_NOT_FOUND;
}



