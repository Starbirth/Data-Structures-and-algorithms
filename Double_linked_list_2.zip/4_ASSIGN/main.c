/**************************************************************
DOCUMENTATION:

NAME				: V.KARTHIKEYAN
DATE				: 23.08.2021
DISCRIPTION		: Assignment – 4
				  Implement functions given below :
				  1. dll_insert_after(head, tail, gdata, ndata)
				  2. dll_insert_before(head, gdata, ndata)
				  3. dll_delete_element(head, tail, gdata)

INPUT AND OUTPUT	:
./a.out

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :1
Enter the data to be inserted :5
The data 5 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :2
Enter the node data to be found : 5
Enter the node data to be inserted after 5 : 8
The data 8 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :5

head -> [5] <-> [8] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :3
Enter the node data to be found : 8
Enter the node data to be inserted before 8 : 2
The data 2 is inserted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :5

head -> [5] <-> [2] <-> [8] <- tail
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :4
Enter the node data to be deleted : 2
The node contains data 2 is deleted successfully
DO YOU WANT TO CONTINUE (y/Y): y

1. Insert at last
2. Insert after
3. Insert before
4. Delete element
5. Print list
Enter your choice :5

head -> [5] <-> [8] <- tail
DO YOU WANT TO CONTINUE (y/Y): n

***********************************************************************/
#include "dlist.h"

int main()
{
	/*declaring variables*/
	char choice;
	data_i g_data, n_data, ch, ret;
	
	/*creating a list with head and tail*/
	dlist *head = NULL;
	dlist *tail = NULL;

	do
	{
		printf("\n1. Insert at last\n2. Insert after\n3. Insert before\n4. Delete element\n5. Print list\nEnter your choice :");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1:
				/*to insert a new node at the last*/
				printf("Enter the data to be inserted :");
				scanf("%d", &n_data);
				if( (ret = insert_at_last(&head, &tail, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else
				{
					printf("Failed to create a new node\n");
				}
				break;
			case 2:
				/*insert a new node after the given node*/
				printf("Enter the node data to be found : ");
				scanf("%d", &g_data);
				printf("Enter the node data to be inserted after %d : ",g_data);
				scanf("%d", &n_data);
				if( (ret = insert_after (&head, &tail, g_data, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else if( ret == DATA_NOT_FOUND )
				{
					printf("The node data %d is not present in the link\n",g_data);
				}
				else if( ret == FAILURE )
				{
					printf("Unable to create new node");
				}
				else
				{
					printf("No link is present\n");
				}
				break;
			case 3:
				/*insert a new node before the given node*/
				printf("Enter the node data to be found : ");
				scanf("%d", &g_data);
				printf("Enter the node data to be inserted before %d : ",g_data);
				scanf("%d", &n_data);
				if( (ret = insert_before (&head, &tail, g_data, n_data)) == SUCCESS )
				{
					printf("The data %d is inserted successfully\n",n_data);
				}
				else if( ret == DATA_NOT_FOUND )
				{
					printf("The node data %d is not present in the link\n",g_data);
				}
				else if( ret == FAILURE )
				{
					printf("Unable to create new node");
				}
				else
				{
					printf("No link is present\n");
				}
				break;
			case 4:
				/*delete the node with the given data*/
				printf("Enter the node data to be deleted : ");
				scanf("%d", &n_data);
				if( (ret = delete_element(&head, &tail, n_data)) == SUCCESS)
				{
					printf("The node contains data %d is deleted successfully\n", n_data);
				}
				else if(ret == EMPTY_LIST)
				{
					printf("No link is present\n");
				}
				else if(ret == DATA_NOT_FOUND)
				{
					printf("The Data %d is not found in the list\n", n_data);
				}
				break;
			case 5:
				/*print the list*/
				if( print_list(head) != SUCCESS) 
					printf("No link is present\n");
				break;
			default:
				printf("\nINFO : Invalid choice of operation\n");
				break;
			}	
	printf("DO YOU WANT TO CONTINUE (y/Y): ");
	scanf(" %c",&choice);
	} while(choice == 'Y' || choice == 'y');
	
	return 0;
}




